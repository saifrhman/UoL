"""
homemade.py for COMP532 chess bot.

Drop this file into your lichess-bot clone (or append the Comp532Bot
class to the existing homemade.py). Then in config.yml set:
    engine.protocol: homemade
    engine.name:     Comp532Bot

Pick the agent at runtime via the COMP532_AGENT environment variable:
    export COMP532_AGENT=heuristic   # default
    export COMP532_AGENT=drl         # value-net agent
    export COMP532_AGENT=llm         # OpenRouter / Anthropic / OpenAI

For the LLM agent, set OPENROUTER_API_KEY (preferred) or ANTHROPIC_API_KEY
in the shell. *Never* commit a key into this file.
"""
from __future__ import annotations

import abc
import math
import os
import random
import re
from typing import Optional

import chess
import chess.engine
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# lichess-bot's homemade-engine base class. The wiki says "extend
# MinimalEngine in homemade.py"; recent versions of lichess-bot ship
# ExampleEngine = MinimalEngine in the same file. We try both.
try:
    from lib.engine_wrapper import MinimalEngine                  # newer layout
except ImportError:
    try:
        from strategies import MinimalEngine                       # older layout
    except ImportError:
        # Last resort -- if the user has appended this file inline,
        # MinimalEngine is already in scope as a top-level name.
        MinimalEngine = object  # type: ignore[assignment]

try:
    from chess.engine import PlayResult
except ImportError:
    PlayResult = None  # very old python-chess

# ====================================================================
# 1. Heuristic agent (material + PSTs + 1-ply)
# ====================================================================
PIECE_VALUE = {chess.PAWN:100, chess.KNIGHT:320, chess.BISHOP:330,
               chess.ROOK:500, chess.QUEEN:900,  chess.KING:20_000}

_PAWN_PST = [ 0, 0, 0, 0, 0, 0, 0, 0,  5,10,10,-20,-20,10,10, 5,
              5,-5,-10,0, 0,-10,-5,5,  0, 0, 0,20,20, 0, 0, 0,
              5, 5,10,25,25,10, 5, 5, 10,10,20,30,30,20,10,10,
             50,50,50,50,50,50,50,50,  0, 0, 0, 0, 0, 0, 0, 0]
_KNIGHT_PST = [-50,-40,-30,-30,-30,-30,-40,-50, -40,-20, 0, 5, 5, 0,-20,-40,
               -30,  5,10,15,15,10,  5,-30, -30,  0,15,20,20,15,  0,-30,
               -30,  5,15,20,20,15,  5,-30, -30,  0,10,15,15,10,  0,-30,
               -40,-20, 0, 0, 0, 0,-20,-40, -50,-40,-30,-30,-30,-30,-40,-50]
_BISHOP_PST = [-20,-10,-10,-10,-10,-10,-10,-20, -10, 5, 0, 0, 0, 0, 5,-10,
               -10,10,10,10,10,10,10,-10,    -10, 0,10,10,10,10, 0,-10,
               -10, 5, 5,10,10, 5, 5,-10,    -10, 0, 5,10,10, 5, 0,-10,
               -10, 0, 0, 0, 0, 0, 0,-10,    -20,-10,-10,-10,-10,-10,-10,-20]
_ROOK_PST = [ 0, 0, 0, 5, 5, 0, 0, 0,  -5, 0, 0, 0, 0, 0, 0,-5,
             -5, 0, 0, 0, 0, 0, 0,-5,  -5, 0, 0, 0, 0, 0, 0,-5,
             -5, 0, 0, 0, 0, 0, 0,-5,  -5, 0, 0, 0, 0, 0, 0,-5,
              5,10,10,10,10,10,10, 5,   0, 0, 0, 0, 0, 0, 0, 0]
_QUEEN_PST = [-20,-10,-10,-5,-5,-10,-10,-20, -10, 0, 5, 0, 0, 0, 0,-10,
              -10, 5, 5, 5, 5, 5, 0,-10,    0, 0, 5, 5, 5, 5, 0,-5,
               -5, 0, 5, 5, 5, 5, 0,-5,    -10, 0, 5, 5, 5, 5, 0,-10,
              -10, 0, 0, 0, 0, 0, 0,-10,   -20,-10,-10,-5,-5,-10,-10,-20]
_KING_PST = [ 20,30,10, 0, 0,10,30,20, 20,20, 0, 0, 0, 0,20,20,
             -10,-20,-20,-20,-20,-20,-20,-10,  -20,-30,-30,-40,-40,-30,-30,-20,
             -30,-40,-40,-50,-50,-40,-40,-30,  -30,-40,-40,-50,-50,-40,-40,-30,
             -30,-40,-40,-50,-50,-40,-40,-30,  -30,-40,-40,-50,-50,-40,-40,-30]
_PST = {chess.PAWN:_PAWN_PST, chess.KNIGHT:_KNIGHT_PST, chess.BISHOP:_BISHOP_PST,
        chess.ROOK:_ROOK_PST, chess.QUEEN:_QUEEN_PST, chess.KING:_KING_PST}

def heur_eval(board: chess.Board) -> int:
    s = 0
    for sq, p in board.piece_map().items():
        v = PIECE_VALUE[p.piece_type]
        idx = sq if p.color == chess.WHITE else chess.square_mirror(sq)
        v += _PST[p.piece_type][idx]
        s += v if p.color == chess.WHITE else -v
    return s

class HeuristicAgent:
    def __init__(self, seed: int = 0): self.rng = random.Random(seed)
    def select_move(self, board):
        legal = list(board.legal_moves)
        is_white = board.turn == chess.WHITE
        best = -10**9; pool = []
        for mv in legal:
            board.push(mv)
            if board.is_checkmate(): board.pop(); return mv
            v = heur_eval(board);  v = v if is_white else -v
            board.pop()
            if v > best:    best = v; pool = [mv]
            elif v == best: pool.append(mv)
        return self.rng.choice(pool)

# ====================================================================
# 2. DRL agent (CNN value network + 1-ply look-ahead)
# ====================================================================
PIECES = (chess.PAWN, chess.KNIGHT, chess.BISHOP,
          chess.ROOK, chess.QUEEN, chess.KING)

def board_to_tensor(board: chess.Board) -> np.ndarray:
    t = np.zeros((18, 8, 8), dtype=np.float32)
    for sq, piece in board.piece_map().items():
        plane = PIECES.index(piece.piece_type) + (6 if piece.color == chess.BLACK else 0)
        r, c = chess.square_rank(sq), chess.square_file(sq)
        t[plane, 7-r, c] = 1.0
    if board.has_kingside_castling_rights(chess.WHITE):  t[12,:,:] = 1.0
    if board.has_queenside_castling_rights(chess.WHITE): t[13,:,:] = 1.0
    if board.has_kingside_castling_rights(chess.BLACK):  t[14,:,:] = 1.0
    if board.has_queenside_castling_rights(chess.BLACK): t[15,:,:] = 1.0
    if board.turn == chess.WHITE: t[16,:,:] = 1.0
    if board.ep_square is not None:
        r, c = chess.square_rank(board.ep_square), chess.square_file(board.ep_square)
        t[17, 7-r, c] = 1.0
    return t

class ValueNet(nn.Module):
    def __init__(self, channels: int = 32):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv2d(18, channels, 3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1), nn.ReLU(inplace=True),
        )
        self.head = nn.Sequential(
            nn.AdaptiveAvgPool2d(1), nn.Flatten(),
            nn.Linear(channels, 64), nn.ReLU(inplace=True),
            nn.Linear(64, 1), nn.Tanh(),
        )
    def forward(self, x): return self.head(self.body(x)).squeeze(-1)

class DRLAgent:
    def __init__(self, model_path: str = 'models/chess_drl.pt', seed: int = 0):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.net = ValueNet().to(self.device)
        if model_path and os.path.exists(model_path):
            sd = torch.load(model_path, map_location=self.device, weights_only=False)
            self.net.load_state_dict(sd['net'] if 'net' in sd else sd)
            print(f'[Comp532Bot] Loaded DRL weights from {model_path}')
        else:
            print(f'[Comp532Bot] WARNING: no DRL weights at {model_path}; '
                  'using random-init network (very weak).')
        self.net.eval()
        self.rng = random.Random(seed)

    @torch.no_grad()
    def select_move(self, board):
        legal = list(board.legal_moves)
        tensors, scored = [], []
        for mv in legal:
            board.push(mv)
            if board.is_checkmate():
                board.pop(); return mv
            if board.is_stalemate() or board.is_insufficient_material():
                tensors.append(board_to_tensor(board)); scored.append((mv, 0.0))
                board.pop(); continue
            tensors.append(board_to_tensor(board)); scored.append((mv, None))
            board.pop()
        if any(s is None for _, s in scored):
            x = torch.from_numpy(np.stack(tensors)).to(self.device)
            v = self.net(x).cpu().numpy()
        else:
            v = np.zeros(len(scored))
        best = float('inf'); pool = []
        for i, (mv, s) in enumerate(scored):
            score = s if s is not None else float(v[i])
            if   score < best - 1e-6:        best = score; pool = [mv]
            elif abs(score - best) < 1e-6:   pool.append(mv)
        return self.rng.choice(pool)

# ====================================================================
# 3. LLM agent (OpenRouter Claude Opus 4.6, with full repair pipeline)
# ====================================================================
SYSTEM_PROMPT = (
    "You are a chess engine. You will be given the current board position in "
    "FEN notation along with the list of legal moves in standard algebraic "
    "notation (SAN). Reply with EXACTLY ONE legal move in SAN. Do not include "
    "any other text, commentary, punctuation, or move number. Choose the move "
    "that is best for the side to move."
)
_PREAMBLE_RE = re.compile(
    r'^(my move is|i play|i would play|i choose|the best move is|move:?)\s*',
    flags=re.IGNORECASE,
)

def _build_user_prompt(board) -> str:
    legal_san = sorted(board.san(m) for m in board.legal_moves)
    side = 'White' if board.turn == chess.WHITE else 'Black'
    return (f'Position (FEN): {board.fen()}\n'
            f'Side to move: {side}\n'
            f'Legal moves ({len(legal_san)}): ' + ' '.join(legal_san) +
            '\nReply with one SAN move only.')

def _parse_san(text, board):
    if not text: return None
    s = text.strip().strip('."\'`')
    s = _PREAMBLE_RE.sub('', s).strip()
    s = (s.split()[0] if s.split() else s).strip('.,;:!?')
    try: return board.parse_san(s)
    except Exception:
        try:
            mv = chess.Move.from_uci(s.lower())
            return mv if mv in board.legal_moves else None
        except ValueError: return None

class LLMAgent:
    def __init__(self, model: Optional[str] = None, seed: int = 0):
        self.openrouter_key = os.environ.get('OPENROUTER_API_KEY', '')
        self.anthropic_key  = os.environ.get('ANTHROPIC_API_KEY',  '')
        self.model = model or os.environ.get('COMP532_LLM_MODEL', 'anthropic/claude-opus-4.6')
        self.max_retries = 2
        self._fallback = HeuristicAgent(seed=seed)
        if not (self.openrouter_key or self.anthropic_key):
            raise RuntimeError(
                'LLMAgent requires OPENROUTER_API_KEY or ANTHROPIC_API_KEY.')

    def _call(self, board, hint=''):
        prompt = _build_user_prompt(board) + (f'\n\nNOTE: {hint}' if hint else '')
        if self.openrouter_key:
            from openai import OpenAI
            client = OpenAI(api_key=self.openrouter_key,
                            base_url='https://openrouter.ai/api/v1')
            resp = client.chat.completions.create(
                model=self.model,
                messages=[{'role':'system','content':SYSTEM_PROMPT},
                          {'role':'user','content':prompt}],
                temperature=0.2, max_tokens=8,
                extra_headers={
                    'HTTP-Referer': 'https://github.com/comp532-cw2-chess',
                    'X-Title': 'COMP532 chess bot',
                },
            )
            return resp.choices[0].message.content or ''
        else:
            import anthropic
            c = anthropic.Anthropic(api_key=self.anthropic_key)
            r = c.messages.create(
                model=self.model, system=SYSTEM_PROMPT,
                messages=[{'role':'user','content':prompt}],
                max_tokens=12, temperature=0.2,
            )
            return ''.join(b.text for b in r.content if getattr(b, 'type', None) == 'text')

    def select_move(self, board):
        hint = ''
        for _ in range(self.max_retries + 1):
            try:
                text = self._call(board, hint=hint)
            except Exception as e:
                print(f'[Comp532Bot] LLM call failed: {e}; using heuristic fallback')
                return self._fallback.select_move(board)
            mv = _parse_san(text, board)
            if mv is not None: return mv
            hint = f"Your previous response {text!r} was not a legal SAN move."
        print('[Comp532Bot] LLM exhausted retries; using heuristic fallback')
        return self._fallback.select_move(board)

# ====================================================================
# 4. The lichess-bot homemade engine class
# ====================================================================
AGENT_NAME = os.environ.get('COMP532_AGENT', 'heuristic').lower()
DRL_MODEL_PATH = os.environ.get(
    'COMP532_DRL_MODEL', 'models/chess_drl.pt')

def _make_agent():
    if AGENT_NAME == 'heuristic': return HeuristicAgent(seed=0)
    if AGENT_NAME == 'drl':       return DRLAgent(model_path=DRL_MODEL_PATH)
    if AGENT_NAME == 'llm':       return LLMAgent()
    raise ValueError(f'Unknown COMP532_AGENT={AGENT_NAME!r}; '
                     'use heuristic|drl|llm')

class Comp532Bot(MinimalEngine):
    """Homemade lichess-bot engine that wraps a COMP532 chess agent.

    lichess-bot's contract: implement search(board, time_limit, ponder,
    draw_offered, root_moves) and return either a chess.Move (older API)
    or a chess.engine.PlayResult (current API). We return PlayResult when
    importable and a bare Move otherwise.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs) if MinimalEngine is not object else None
        self.agent = _make_agent()
        print(f'[Comp532Bot] ready: agent={AGENT_NAME}')

    def search(self, board, time_limit, ponder, draw_offered, root_moves):
        mv = self.agent.select_move(board)
        if PlayResult is not None:
            return PlayResult(mv, None)
        return mv
